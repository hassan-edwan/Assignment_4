public class ManagementCompany {
	String name;
	String taxID;
	double fee;
	final int MAX_PROPERTY = 5;
	final int MGMT_WIDTH = 10, MGMT_DEPTH = 10;
	Property[] properties = new Property[MAX_PROPERTY];
	Plot plot;
	int number_of_properties = 0;

	public ManagementCompany(String name, String id, double fee, int x, int y, int width, int depth) {
		properties = new Property[MAX_PROPERTY];
		this.name = name;
		taxID = id;
		this.fee = fee;
		this.plot = new Plot(x, y, width, depth);
	}

	public ManagementCompany(String name, String id, double fee) {
		this.name = name;
		taxID = id;
		this.fee = fee;
	}

	public int getMAX_PROPERTY() {
		return MAX_PROPERTY;
	}

	public int addProperty(Property property) {


		if (number_of_properties >= MAX_PROPERTY) {
			return -1;
		}

		if (property == null) {
			return -2;
		}
		for(int i = 0; i < number_of_properties; i++) {
			if (properties[i].getPlot().encompasses(property.getPlot())) {
				return -3;
			}
		}
		for (int i = 0; i < number_of_properties; i++) {
			if (properties[i].getPlot().overlaps(property.getPlot())) {
				return -4;
			}
		}
		properties[number_of_properties] = property;
		number_of_properties++;
		return number_of_properties - 1;

	}

	public int addProperty(String name, String city, double rent, String owner) {

		Property property = new Property(name, city, rent, owner, 0, 0, 1, 1);
		
		if (number_of_properties >= MAX_PROPERTY) {
			return -1;
		}

		for(int i = 0; i < number_of_properties; i++) {
			if (properties[i].getPlot().encompasses(property.getPlot())) {
				return -3;
			}
		}
		for (int i = 0; i < number_of_properties; i++) {
			if (properties[i].getPlot().overlaps(property.getPlot())) {
				return -4;
			}
		}
		properties[number_of_properties] = property;
		number_of_properties++;
		return number_of_properties - 1;
	}

	public int addProperty(String name, String city, double rent, String owner, int x, int y, int width, int depth) {

		Property property = new Property(name, city, rent, owner, x, y, width, depth);
		
		if (number_of_properties >= MAX_PROPERTY) {
			return -1;
		}
		for(int i = 0; i < number_of_properties; i++) {
			if (properties[i].getPlot().encompasses(property.getPlot())) {
				return -3;
			}
		}
		for (int i = 0; i < number_of_properties; i++) {
			if (properties[i].getPlot().overlaps(property.getPlot()))
				return -4;
		}

		properties[number_of_properties] = property;
		number_of_properties++;
		return number_of_properties - 1;
	}

	public double totalRent() {
		int total = 0;
		for (int i = 0; i < number_of_properties; i++) {
			total += properties[i].getRentAmount();
		}
		return total;
	}

	public int maxRentPropertyIndex() {
		int maxIndex = 0;
		for (int i = 0; i < number_of_properties; i++) {
			if (properties[i].getRentAmount() >= properties[maxIndex].getRentAmount()) {
				maxIndex = i;
			}
		}
		return maxIndex;
	}

	public double maxRentProp() {
		return properties[maxRentPropertyIndex()].getRentAmount();
	}

	public String toString() {
		String string = "";
		double fee = 0;
		for (int i = 0; i < number_of_properties; ++i) {
			fee += (this.fee * properties[i].getRentAmount()) / 100;
		}
		for (int i = 0; i < number_of_properties; ++i) {
			string += properties[i].toString() + "\n";
		}
		string += "Total management fee collected is " + fee + "\n";
		return string;
	}

	public Plot getPlot() {
		return new Plot(plot);
	}

	public String getName() {
		return name;
	}

	public String getTaxID() {
		return taxID;
	}

	public double getFee() {
		return fee;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setTaxID(String taxID) {
		this.taxID = taxID;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	public void setPlot(Plot plot) {
		this.plot = new Plot(plot);
	}

}