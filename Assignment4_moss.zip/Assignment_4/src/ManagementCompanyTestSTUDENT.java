

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class ManagementCompanyTestSTUDENT {
	
	Property property, property1, property2, property3, property4, property5;
	ManagementCompany management;
	
	@Before
	public void setUp() throws Exception {
		property = new Property ("house", "test", 10, "Hassan Edwan",11,11,1,1);
		property4 = new Property ("houses", "tests", 5, "Hassan Edwan", 100, 100, 1, 1);
		property5 = new Property("houses", "tests", 15, "Hassan Edwan", 50, 50, 1, 1);
		management = new ManagementCompany("Blah", "123456", 3);
		
		management.addProperty(property5);
		management.addProperty(property);
		management.addProperty(property4);
		
	}

	@After
	public void tearDown() {
		//student set mgmt co to null  
		property = property1 = property2 = property3 = property4 = property5= null;
		management = null;
	}

	@Test
	public void testAddPropertyDefaultPlot() {
		//student should add property with 4 args & default plot (0,0,1,1)
		property1 = new Property("house", "test", 5, "Hassan Edwan", 0, 0, 1, 1);
		assertEquals(management.addProperty(property1), 3, 0);
		//student should add property with 8 args
		property2 = new Property ("house", "test", 25, "Hassan Edwan",4,1,2,2);
		assertEquals(management.addProperty(property2), 4, 0);

		//student should add property that exceeds the size of the mgmt co array and can not be added, add property should return -1
		property3 = new Property ("overflow", "test", 20, "Hassan Edwan",8,8,2,2);
		assertEquals(management.addProperty(property3), -1, 0);

		
	}
 
	@Test
	public void testMaxRentProp() {
		assertEquals(management.maxRentProp(),15 ,0);

	}

	@Test
	public void testTotalRent() {
		assertEquals(management.totalRent(),30,0);
		//student should test if totalRent returns the total rent of properties
	}

 }
