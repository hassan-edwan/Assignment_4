public class Property {

	String propertyName;
	String cityName;
	double rentAmount;
	String ownerName;
	Plot plot;
	
	public Property(Property property) {	
		this.propertyName = property.getPropertyName();
		this.cityName = property.getCityName();
		this.rentAmount = property.getRentAmount();
		this.ownerName = property.getOwnerName();
		this.plot = property.getPlot();
	}

	public Property(String propertyName, String cityName, double rentAmount, String ownerName, int x, int y, int width, int depth) {
		this.propertyName = propertyName;
		this.cityName = cityName;
		this.rentAmount = rentAmount;
		this.ownerName = ownerName;
		this.plot = new Plot(x, y, width, depth);
	}
	
	
	public Property(String propertyName, String cityName, double rentAmount, String ownerName) {
		this.propertyName = propertyName;
		this.cityName = cityName;
		this.rentAmount = rentAmount;
		this.ownerName = ownerName;
		this.plot = new Plot(0, 0, 1, 1);
	}
	public String toString() {
		return "Property Name :" + propertyName + " City :" + cityName + " Rent :" + rentAmount + " Owner :"
				+ ownerName;
	}

	public String getPropertyName() {
		return propertyName;
	}
	
	public String getOwnerName() {
		return ownerName;
	}	
	
	public String getCityName() {
		return cityName;
	}
	public Plot getPlot() {
		return plot;
	}
	
	public double getRentAmount() {
		return rentAmount;
	}
	
	public void setPropertyName(String property) {
		propertyName = property;
	}

	public void setCityName(String city) {
		cityName = city;
	}

	public void setRentAmount(double rent) {
		rentAmount = rent;
	}

	public void setOwnerName(String owner) {
		ownerName = owner;
	}
	public void setPlot(int x, int y, int width, int depth) {
		this.plot = new Plot(x, y, width, depth);
	}

}