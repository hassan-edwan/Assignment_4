
public class Plot {
	int x;
	int y;
	int depth;
	int width;
	
	public Plot() {
		this.x = 0;
		this.y = 0;
		this.width = 1;
		this.depth = 1;
	}
	
	Plot(Plot plot) {
		this.x = plot.getX();
		this.y = plot.getY();
		this.depth = plot.getDepth();
		this.width = plot.getWidth();
	}

	Plot(int x, int y, int width, int depth) {
		this.x = x;
		this.y = y;
		this.depth = depth;
		this.width = width;
	}

	public String toString() {
		String string = "Upper left: (" + x + "," + y + "); Width: " + depth + " Depth: " + width;
		return string;
	}

	public boolean overlaps(Plot plot) {
		if (x < plot.x + plot.width) {
			if (x + width > plot.x) {
				if (y < plot.y + plot.depth) {
					if (y + depth > plot.y) {
						return true;
					}
				}
			}
		}
		return false;
	}

	   public boolean encompasses(Plot plot) {
	       double rightX = x + width;
	       double bottomY = y + depth;
	       double plotRightX = plot.getX()+plot.getWidth();
	       double plotBottomY = plot.getY() + plot.getDepth();
	       if(this.x <= plot.getX() ) {
	    	   if(plot.getX() <= rightX) {
	    		   if(this.y <= plot.getY()) {
	    			   if(plot.getY() <= bottomY) {
	    				   if(this.x <= rightX) {
	    					   if(plotRightX <= rightX) {
	    						   if(this.y<=plotBottomY) {
	    							   if(plotBottomY<=bottomY) {
	    								   return true;
	    							   }
	    						   }
	    					   }
	    				   }
	    			   }
	    		   }
	    	   }
	       }
	       return false;
	   }
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getDepth() {
		return depth;
	}

	public int getWidth() {
		return width;
	}

	public void setX(int x) {
		this.x = x;
	}

	public void setY(int y) {
		this.y = y;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}

	public void setWidth(int width) {
		this.width = width;
	}

}